<?php
    // ontwikkel database
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbase = "pamhanze";
?>