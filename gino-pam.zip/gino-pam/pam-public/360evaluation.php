<?php
require_once('./root_pam_config.inc.php');
if ($pam_ini_done != TRUE) die('pam configuratie niet gelukt');

require_once('threesixty/360evaluation.inc.php');

?>
