
xajax.callback.global.onRequest = function() {xajax.$('global_loading').style.display = 'block';}
xajax.callback.global.beforeResponseProcessing = function() {xajax.$('global_loading').style.display='none';}


