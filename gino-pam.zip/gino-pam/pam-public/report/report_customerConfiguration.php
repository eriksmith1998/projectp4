<?php
    require_once("./root_report_config.inc.php");
//
    $time = $_GET['time'];
    require_once("report_jrxml/customerConfiguration_report.php");


?>
