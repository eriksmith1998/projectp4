<?php
    // Waar staan we
    $htdocdir = dirname(__file__);
    // de echte pam config opzoeken
    require_once($htdocdir . '/../php_pam_config.inc.php');
?>
