<?php
if (!PAM_DISABLED) {
    // Blijkbaar zijn er nog functies die iets willen lezen/schrijven naar de database voordat deze regel wordt uitgevoerd.
    //mysql_close($conn);
}
?>