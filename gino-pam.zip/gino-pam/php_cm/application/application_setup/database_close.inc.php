<?php

require_once('application/application_setup/database/closeConnection.inc.php');

?>
