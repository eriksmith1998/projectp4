<?php

require_once('application/library/applicationConsts.inc.php');
require_once('application/model/queries/ConfigQueries.class.php');

?>
