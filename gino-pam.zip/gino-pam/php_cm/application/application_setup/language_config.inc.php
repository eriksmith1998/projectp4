<?php

require_once('application/interface/language.inc.php');


?>