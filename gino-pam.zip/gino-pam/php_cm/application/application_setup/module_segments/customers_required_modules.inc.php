<?php

require_once('modules/customers.php');

require_once('modules/logout.php');

?>