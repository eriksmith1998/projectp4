<?php

$xajax->register(XAJAX_FUNCTION, 'moduleLogin_processLogin');

?>
