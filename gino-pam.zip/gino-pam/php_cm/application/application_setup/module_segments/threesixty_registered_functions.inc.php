<?php

$xajax->register(XAJAX_FUNCTION, 'module360Evaluation_showCompetenceDetails_deprecated');
$xajax->register(XAJAX_FUNCTION, 'module360Evaluation_hideCompetenceDetails_deprecated');
$xajax->register(XAJAX_FUNCTION, 'module360_saveEvaluation_deprecated');

?>
