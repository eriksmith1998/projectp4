<?php

// Zolang de deprecated versie naast de nieuwe versie moet staan is het beter om de beslissing op een andere plek te houden

?>
