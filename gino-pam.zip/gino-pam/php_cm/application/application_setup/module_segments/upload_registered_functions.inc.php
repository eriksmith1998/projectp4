<?php

$xajax->register(XAJAX_FUNCTION, 'moduleSelectEmployees_control');

?>
