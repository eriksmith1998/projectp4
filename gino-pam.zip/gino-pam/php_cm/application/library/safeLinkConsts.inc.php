<?php
define('SAFELINK_EMPLOYEES__EDIT_EMPLOYEE','employees_edit employee');
?>
