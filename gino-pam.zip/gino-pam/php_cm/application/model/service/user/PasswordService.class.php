<?php

/**
 * Description of PasswordService
 *
 * @author ben.dokter
 */

require_once('application/model/valueobjects/user/PasswordValueObject.class.php');

class PasswordService
{

}

?>
