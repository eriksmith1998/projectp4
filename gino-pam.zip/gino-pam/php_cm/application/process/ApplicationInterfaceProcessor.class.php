<?php

/**
 * Description of ApplicationInterfaceProcessor
 *
 * @author ben.dokter
 */

require_once('application/process/user/PasswordInterfaceProcessor.class.php');
require_once('application/process/user/UserLevelSwitchInterfaceProcessor.class.php');

class ApplicationInterfaceProcessor
{
}

?>
