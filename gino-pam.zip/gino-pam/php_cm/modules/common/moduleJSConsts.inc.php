<?php
/*
 * Ter voorkoming van magic numbers in de code
 */

define('JS_DEFAULT_DATE_FORMAT', "'%d-%m-%Y'");
define('JS_RELATIVE_DAYS_DEADLINE', -14);

?>
