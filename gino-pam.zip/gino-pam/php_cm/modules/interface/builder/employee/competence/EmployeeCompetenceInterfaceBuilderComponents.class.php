<?php

/**
 * Description of EmployeeCompetenceInterfaceBuilderComponents
 *
 * @author hans.prins
 */
class EmployeeCompetenceInterfaceBuilderComponents
{
}

?>
