<?php

/**
 * Description of EmployeeProfileInterfaceBuilderComponents
 *
 * @author ben.dokter
 */

class EmployeeProfileInterfaceBuilderComponents
{

//    static function getPrintLink($employeeId)
//    {
//        $html = '';
//        if (PermissionsService::isPrintAllowed(PERMISSION_EMPLOYEE_PROFILE)) {
//            $html .= InterfaceBuilder::iconLink('printProfile',
//                                                TXT_UCF('GENERATE_EMPLOYEE_PROFILE_PRINT'),
//                                                'xajax_moduleEmployees_printProfile_deprecated(' . $employeeId . ');',
//                                                ICON_PRINT);
//        }
//        return $html;
//    }

}

?>
