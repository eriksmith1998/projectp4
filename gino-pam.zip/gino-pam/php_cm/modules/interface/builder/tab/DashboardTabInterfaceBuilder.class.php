<?php

/**
 * Description of DashboardTabInterfaceBuilder
 *
 * @author ben.dokter
 */

require_once('modules/interface/builder/tab/BaseContentTabInterfaceBuilder.class.php');

class DashboardTabInterfaceBuilder extends BaseContentTabInterfaceBuilder
{

}

?>
