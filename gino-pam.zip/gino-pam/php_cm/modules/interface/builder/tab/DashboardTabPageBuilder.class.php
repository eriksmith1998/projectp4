<?php


/**
 * Description of DashboardTabPageBuilder
 *
 * @author ben.dokter
 */
require_once('modules/interface/builder/tab/BaseContentTabPageBuilder.class.php');

class DashboardTabPageBuilder extends BaseContentTabPageBuilder
{

}

?>
