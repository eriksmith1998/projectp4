<?php

/**
 * Description of OrganisationTabInterfaceBuilder
 *
 * @author ben.dokter
 */

require_once('modules/interface/interfaceobjects/tab/GenericMenuTabView.class.php');
require_once('modules/interface//builder/tab/BaseContentTabPageBuilder.class.php');

class OrganisationTabInterfaceBuilder extends BaseContentTabPageBuilder
{

}

?>
