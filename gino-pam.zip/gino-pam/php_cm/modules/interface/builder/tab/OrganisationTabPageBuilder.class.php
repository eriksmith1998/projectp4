<?php

/**
 * Description of OrganisationTabPageBuilder
 *
 * @author ben.dokter
 */

require_once('modules/interface/builder/tab/BaseContentTabPageBuilder.class.php');

class OrganisationTabPageBuilder extends BaseContentTabPageBuilder
{

//    static function getMenuPageHtml($leftWidth,
//                                    $menuPanelHtmlId,
//                                    $contentPanelHtmlId)
//    {
//        return OrganisationTabInterfaceBuilder::getMenuViewHtml($leftWidth,
//                                                                $menuPanelHtmlId,
//                                                                $contentPanelHtmlId);
//    }
//
//    static function getContentPageHtml( $contentWidth,
//                                        $contentPanelHtmlId,
//                                        $contentHtml)
//    {
//        return OrganisationTabInterfaceBuilder::getContentViewHtml( $contentWidth,
//                                                                    $contentPanelHtmlId,
//                                                                    $contentHtml);
//    }
}

?>
