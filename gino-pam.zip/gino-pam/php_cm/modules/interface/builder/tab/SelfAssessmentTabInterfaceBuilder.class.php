<?php

/**
 * Description of SelfAssessmentTabInterfaceBuilder
 *
 * @author ben.dokter
 */

require_once('modules/interface/builder/tab/BaseContentTabInterfaceBuilder.class.php');

class SelfAssessmentTabInterfaceBuilder extends BaseContentTabInterfaceBuilder
{

}

?>
