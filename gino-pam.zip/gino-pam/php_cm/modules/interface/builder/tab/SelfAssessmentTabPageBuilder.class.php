<?php


/**
 * Description of SelfAssessmentTabPageBuilder
 *
 * @author ben.dokter
 */
require_once('modules/interface/builder/tab/BaseContentTabPageBuilder.class.php');

class SelfAssessmentTabPageBuilder extends BaseContentTabPageBuilder
{
//    static function getMenuPageHtml($leftWidth,
//                                    $menuPanelHtmlId,
//                                    $contentPanelHtmlId)
//    {
//        return SelfAssessmentTabInterfaceBuilder::getMenuViewHtml(  $leftWidth,
//                                                                    $menuPanelHtmlId,
//                                                                    $contentPanelHtmlId);
//    }
//
//    static function getContentPageHtml( $contentWidth,
//                                        $contentPanelHtmlId,
//                                        $contentHtml)
//    {
//        return SelfAssessmentTabInterfaceBuilder::getContentViewHtml(   $contentWidth,
//                                                                        $contentPanelHtmlId,
//                                                                        $contentHtml);
//    }
//
}

?>
